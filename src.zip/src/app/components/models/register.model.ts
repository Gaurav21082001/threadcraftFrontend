export interface Signup{
    name:string,
    email:string,
    password:string,
    confirmPassword:string,
    phoneNumber:string,
    address:string
}