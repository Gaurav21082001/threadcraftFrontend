export interface AuthUser{
    email:string,
    role:any
}