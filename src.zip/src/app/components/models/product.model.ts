export interface Product{
    productId:number,
    productName:string,
    description:string,
    price:number,
    stock:number,
    categoryId:number,
    status:number,
    dateTime:string,
    imageUrl:string,
    
}