import { Component } from '@angular/core';
import { CartService } from '../../../services/cart.service';

@Component({
  selector: 'app-admin-orders',
  templateUrl: './admin-orders.component.html',
  styleUrl: './admin-orders.component.css'
})
export class AdminOrdersComponent {
  groupedOrders: {[key:string]:any}=[];
  customerList:any=[];
  constructor(private cartService:CartService){}
  
  getAllOrders(){
    this.cartService.getAllOrders().subscribe((res:any)=>{
      let groupedOrders=res.result.reduce((r:any,a:any)=>{
        r[a.orderId]=[...r[a.orderId] || [] ,a];
        return r;
      },{});
      console.log(groupedOrders);
      this.groupedOrders=groupedOrders;
    })
    }
  
}
