import { CanActivateFn } from '@angular/router';

export const simpleGuard: CanActivateFn = (route, state) => {
  return true;
};
