export interface Product{
    productId:number,
    productName:string,
    description:string,
    price:number,
    stock:number,
    categoryId:number,
    status:number,
    actualPrice:number,
    imageUrl:string,
    
}