import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from '../../services/auth.service';
import { Signup } from '../models/register.model';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  signupObj: Signup = {
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    phoneNumber: "",
    address: ""
  }

  constructor(private authService: AuthService, private route: Router, private toast: ToastrService) { }

  onSubmit() {
    if (this.isFormValidate()) {
      this.authService.register(this.signupObj).subscribe(
        {
          next: (res: any) => {
            console.log(res);
            this.toast.success("Registered successfully");
            this.route.navigate(['/login']);
          },
          error: (error) => {
            this.toast.error("Please check" + error);
          }
        })
    }

  }

  isFormValidate() {
    let isValid = true;
    const regex = /^[9,8,7,6]{1}\d{9}$/; // Your regex pattern

    if (this.signupObj.name == "" || this.signupObj.name.trim() == "") {
      this.toast.warning("The name is required.");
      isValid = false;
    }
    else if (this.signupObj.email == "" || this.signupObj.email.trim() == "") {
      this.toast.warning("The email is required.");
      isValid = false;
    }
    else if (this.signupObj.password == "" || this.signupObj.password.trim() == "") {
      this.toast.warning("The password is required.");
      isValid = false;
    }
    else if (this.signupObj.confirmPassword == "" || this.signupObj.confirmPassword.trim() == "") {
      this.toast.warning("The confirm password is required.");
      isValid = false;
    }
    else if (this.signupObj.password != this.signupObj.confirmPassword) {
      this.toast.warning("The password and confirm password should be match.");
      isValid = false;
    }
    else if (this.signupObj.phoneNumber == "" || this.signupObj.phoneNumber.trim() == "" || regex.test(this.signupObj.phoneNumber)) {
      this.toast.warning("The phone number is required.");
      isValid = false;
    }
    return isValid;
  }
}
